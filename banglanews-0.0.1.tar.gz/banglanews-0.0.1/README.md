# prothomaloscraper Package

This is a python package to scrape different types of content from the leading Bengali newspaper 'Prothom Alo' 
(https://www.prothomalo.com). The objective of this package is to grab Bengali text 
mainly for the data scientists who need bengai content for research. 
This package was created for absolutely for non-commercial use only, 
and the author does not encourage to use this package for any business 
other than any research tasks. You can check the content from the following link as well: 
(https://github.com/neolithian/prothomalo-scraper/)
